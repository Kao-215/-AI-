const line = require('@line/bot-sdk');
const { lineConfig } = require('../config');

const client = new line.Client(lineConfig);

module.exports = client;
