/**
 * 資料存取層
 * 目前用 lowdb（本機 JSON 檔）示範資料結構與操作邏輯。
 * 正式上線建議換成 MySQL / PostgreSQL / Firestore，
 * 只要保持這個檔案匯出的函式簽名不變，其他程式碼都不用動。
 */
const path = require('path');
const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

const adapter = new FileSync(path.join(__dirname, '../data/db.json'));
const db = low(adapter);

db.defaults({
  rooms: [],
  bookings: [],
  vendors: [],
  counters: { bookingSeq: 0 },
}).write();

// ---------- 會議室 ----------
function getRooms() {
  return db.get('rooms').value();
}

// 取得某天各會議室的租借狀態
function getAvailability(dateStr) {
  const rooms = getRooms();
  const bookingsOnDate = db
    .get('bookings')
    .filter((b) => b.date === dateStr && b.status !== 'rejected')
    .value();

  return rooms.map((room) => {
    const booking = bookingsOnDate.find((b) => b.roomId === room.id);
    return {
      roomId: room.id,
      roomName: room.name,
      status: booking ? booking.status : 'available', // available / pending / approved
      applicant: booking ? booking.applicantName : null,
    };
  });
}

function createBooking({ roomId, date, timeSlot, applicantName, applicantUserId, purpose }) {
  const seq = db.get('counters.bookingSeq').value() + 1;
  db.set('counters.bookingSeq', seq).write();

  const booking = {
    id: `B${String(seq).padStart(4, '0')}`,
    roomId,
    date,
    timeSlot,
    applicantName,
    applicantUserId,
    purpose,
    status: 'pending', // pending / approved / rejected
    createdAt: new Date().toISOString(),
  };
  db.get('bookings').push(booking).write();
  return booking;
}

function getBooking(bookingId) {
  return db.get('bookings').find({ id: bookingId }).value();
}

function updateBookingStatus(bookingId, status) {
  db.get('bookings').find({ id: bookingId }).assign({ status }).write();
  return getBooking(bookingId);
}

// ---------- 進駐費 ----------
function getVendors() {
  return db.get('vendors').value();
}

function getVendorByUserId(userId) {
  return db.get('vendors').find({ userId }).value();
}

function markReminderSent(vendorId, daysBefore) {
  db.get('vendors')
    .find({ id: vendorId })
    .update('remindersSent', (arr) => [...(arr || []), daysBefore])
    .write();
}

function updateVendorStatus(vendorId, status) {
  db.get('vendors').find({ id: vendorId }).assign({ status }).write();
}

module.exports = {
  getRooms,
  getAvailability,
  createBooking,
  getBooking,
  updateBookingStatus,
  getVendors,
  getVendorByUserId,
  markReminderSent,
  updateVendorStatus,
};
