/**
 * 簡易 session store，記錄每個使用者「租借會議室」對話進行到哪一步。
 * 用 Map 存在記憶體中，Server 重啟會清空。
 * 若未來要多台主機水平擴展，建議換成 Redis（介面不變，內部改成 redis get/set）。
 */
const sessions = new Map();

function get(userId) {
  return sessions.get(userId);
}

function set(userId, data) {
  sessions.set(userId, data);
}

function clear(userId) {
  sessions.delete(userId);
}

module.exports = { get, set, clear };
