const cron = require('node-cron');
const db = require('./db');
const { notifyVendorFeeReminder } = require('../handlers/notify');
const { feeReminderDaysBefore, feeCheckCron } = require('../config');

function daysUntil(dateStr) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(dateStr);
  due.setHours(0, 0, 0, 0);
  return Math.round((due - today) / (1000 * 60 * 60 * 24));
}

async function checkAndNotify() {
  const vendors = db.getVendors();
  for (const vendor of vendors) {
    if (vendor.status === 'paid') continue;

    const remaining = daysUntil(vendor.dueDate);
    const alreadySent = vendor.remindersSent || [];

    if (feeReminderDaysBefore.includes(remaining) && !alreadySent.includes(remaining)) {
      try {
        await notifyVendorFeeReminder(vendor, remaining);
        db.markReminderSent(vendor.id, remaining);
        console.log(`已通知廠商 ${vendor.name}，距到期 ${remaining} 天`);
      } catch (err) {
        console.error(`通知廠商 ${vendor.name} 失敗：`, err.message);
      }
    }
  }
}

// 啟動每日排程；也匯出 checkAndNotify 供手動測試/API 觸發
function startScheduler() {
  cron.schedule(feeCheckCron, () => {
    console.log(`[${new Date().toISOString()}] 開始檢查進駐費繳費狀態...`);
    checkAndNotify();
  });
  console.log(`進駐費排程已啟動，cron: ${feeCheckCron}`);
}

module.exports = { startScheduler, checkAndNotify };
